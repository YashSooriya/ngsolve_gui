# Layered Lorentz splash

Reference treatment: a restrained left-to-right highlight wave across the word, not moving or deforming letters.

- `*-layered.svg`: transparent 1448×1086 canvas. `static-splash` contains `logo-wordmark`. The separate `word-illumination` group is clipped by `word-clip`, a complete filled vector outline of the word, including the E. All letter strokes have been expanded into filled paths; there are no text elements or font dependencies. The highlight starts off-canvas, so the layered asset initially shows the static logo.
- `*-animated.svg`: the same layers with a 3.6-second looping SVG sweep. About 2.9 seconds of motion, then a short pause. Reduced-motion preference hides the illumination. SVG animation support depends on your UI renderer; use the layered file for native animation.
- `*-static-2x.png`: transparent 2896×2172 static splash.
- `*-word-2x.png`: transparent word-only layer at the same resolution and coordinates. In this minimal wordmark-only identity it has the same visible pixels as the static splash.
- `*-illumination-mask-2x.png`: white word silhouette with transparency, aligned exactly with the other PNG layers. Tint a moving gradient, mask it with this layer and composite over the static splash.

## Native animation
Draw the base once. Sweep a soft band about 340/1448 of the canvas width from x=-400 to x=1500 (SVG units), clipped to the word. Peak overlay alpha: 0.38. Use white for dark mode and copper #D98A38 for light mode. Keep the base visible. Use a 3.6-second cycle, stop when loading finishes, and disable motion for reduced-motion preferences. Scale positions and band width with the canvas; do not crop PNG layers independently.

Light assets use navy lettering; dark assets use soft white. Both preserve the copper E. No background is embedded in these splash assets.
