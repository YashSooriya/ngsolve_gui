# Lorentz app branding

The current identity uses the Lorentz wordmark with a copper three-bar E. The standalone E is the application mark. Coil artwork is intentionally excluded from this wordmark-based identity.

## Assets
- 01-mark: square transparent SVG, plus transparent PNGs from 16 to 1024 px.
- 02-app-icons: Windows multi-size lorentz.ico (16, 24, 32, 48, 64, 128, 256 px), favicon SVG/ICO, Apple touch icon, web app icons and starter web manifest. Update the manifest icon URLs to your deployed paths.
- 03-wordmarks: light and dark versions as SVG and 3400×520 PNG, each with transparent and background variants. Light means navy lettering for light surfaces; dark means soft-white lettering for dark surfaces.
- 04-home: 480×360 PNGs for the new-project/home card.
- 05-splash: 1448×1086 PNGs, with the centred wordmark and generous clear space. Transparent variants allow the native splash code to supply its background.
- 06-about: 704×396 PNGs for the About dialog. Rename the UI heading to “About Lorentz”.
- 07-guide: preview sheets and palette.json.

## Colour
Copper #D98A38; navy #06264B; soft white #EDF2F7; dark background #101B2B; white #FFFFFF.
Keep copper consistent across themes. Use the light wordmark on light surfaces and the dark wordmark on dark surfaces. The copper application mark is shared across themes.

## Usage
Preserve proportions. Do not stretch or recolour individual bars. Leave at least one bar thickness of clear space around the standalone mark. Wordmark SVGs contain vector paths and require no installed font. Background variants are presentation-ready; transparent variants are intended for app integration. The mark retains transparent padding to fit square icon slots. Web icons use purpose “any”, not “maskable”.

## Animated splash
08-animated-splash contains layered outlined SVGs, animated SVG previews, transparent 2× PNG layers, a local HTML preview and integration notes.
